from django.shortcuts import render

# Create your views here.
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from django import forms



import json
import re
import string
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import TweetTokenizer
import numpy as np
import pandas as pd
import nltk

def chartsent(request):
    form = SentimentForm(request.POST or None)
    context = {}
    if request.method == 'POST':
        if form.is_valid():
            sent = form.cleaned_data.get('Sentence')    # got the sentence
            neg,nue,pos = SentimentAnalyzer(sent)
            R,G,B=colorselect(neg,nue,pos)
            print(R,G,B)
            context['text'] = (R,G,B)
        else:
            form = SentimentForm()

    context['form'] = form
    return render(request, 'app.html', context=context)


def SentimentAnalyzer(text):
    sid_obj = SentimentIntensityAnalyzer()
    sentiment_dict = sid_obj.polarity_scores(text)
    ne=sentiment_dict['neg']
    nu=sentiment_dict['neu']
    po=sentiment_dict['pos']
    print(ne,nu,po)
    return ne,nu,po


class SentimentForm(forms.Form):
    Sentence = forms.CharField(max_length=220, widget=forms.Textarea())

#ChartSentimentColor

def colorselect(ne,nu,po):
    ne_NewValue= round(((round(ne*1000))/1000)*255)
    po_NewValue= round(((round(po*1000))/1000)*255)
    nu_NewValue= round(((round(nu*1000))/1000)*255)
    return ne_NewValue, po_NewValue, nu_NewValue
